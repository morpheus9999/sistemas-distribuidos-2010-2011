package BetPackage;

public enum Result {
    HOME,
    TIE,
    AWAY
}
