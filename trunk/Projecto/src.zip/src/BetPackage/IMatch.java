package BetPackage;


public interface IMatch {
    public String getCode();
    public String getHomeTeam();
    public String getAwayTeam();
}